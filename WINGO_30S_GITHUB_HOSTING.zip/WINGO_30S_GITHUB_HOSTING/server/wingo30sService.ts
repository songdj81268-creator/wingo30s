import {
  clearWingo30sHistory,
  getWingo30sPrediction,
  getWingo30sServiceState,
  listWingo30sPredictions,
  listWingo30sResults,
  resolveWingo30sPrediction,
  setWingo30sFreshBaseline,
  upsertWingo30sPrediction,
  upsertWingo30sResult,
} from "./db";

const ENDPOINTS = [
  "https://ais-pre-s4khmzffgilvco37vb6mk4-346574636584.asia-southeast1.run.app/api/wingo30s/state?__storage_access_granted=1",
  "http://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=10",
  "http://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=100",
  "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=10",
  "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=100",
  "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=50",
  "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json",
];
const PROVIDED_SERVER = "ais-pre-s4khmzffgilvco37vb6mk4-346574636584.asia-southeast1.run.app";
const PROVIDED_SERVER_COOKIE = "__SECURE-aistudio_auth_token=one_token_to_rule_them_all";
const POLL_MS = 250;
const PROVIDER_MIN_INTERVAL_MS = 5_000;
const CORE = [
  "DigitMarkov", "Markov-2", "N-gram-5", "Bayesian", "Entropy", "Gap Analysis",
  "Digit Frequency", "XGBoost proxy", "Random Forest proxy", "LSTM proxy", "Wavelet proxy", "Fourier proxy",
  "Parity Balance", "Neighbor Transition", "Volatility Engine", "Median Bias",
] as const;
const PATTERNS = [
  "Consecutive", "Reverse", "Repeating", "Alternating", "Ascending", "Descending", "Skip Sequence", "Broken Sequence",
  "Short / Long Run", "Immediate Repeat", "Delayed Repeat", "Triple Repeat", "Frequency Repeat", "Repeat Gap", "Repeat Cycle",
  "Pair Transition", "Triple Transition", "4-Step Transition", "5-Gram Transition", "Conditional Transition", "Markov Sequence",
  "Reverse Transition", "Multi-Level Transition", "Arithmetic Progression", "Modular Arithmetic", "Difference Sequence",
  "Gap Distribution", "Periodicity", "Autocorrelation", "Wavelet Scale", "Frequency Spectrum", "Hidden State", "Latent Sequence",
  "Multi-Scale Pattern", "Nonlinear Change", "Historical Similarity", "Pattern Change Detection", "Cluster Sequence", "Anomaly Pattern",
  "Pattern Frequency Validation", "Stability Test", "Out-of-Sample Test", "Significance Test", "False-Pattern Filter",
  "Confidence Calibration", "Pattern Ranking", "Pattern Memory", "Pattern Evolution",
  "Parity Flip", "Parity Run", "High Low Balance", "Digit Neighbor", "Mirror Pair", "Center Bias", "Edge Bias", "Hot Cold Rotation",
  "Volatility Shift", "Rolling Median", "Momentum", "Anti-Streak", "Last-Digit Echo", "Two-Window Drift", "Recent Consensus", "Diversity Guard",
] as const;

type Size = "BIG" | "SMALL";
type ProviderResult = { issue: string; number: number };
export type Wingo30sSnapshot = {
  connection: "LIVE" | "ERROR" | "STARTING" | "FRESH";
  lastPollAt: string | null;
  source: string | null;
  baseline: string | null;
  nextIssue: string | null;
  actualCount: number;
  prediction: Awaited<ReturnType<typeof listWingo30sPredictions>>[number] | null;
  recentResults: Awaited<ReturnType<typeof listWingo30sResults>>;
  recentPredictions: Awaited<ReturnType<typeof listWingo30sPredictions>>;
  error: string | null;
};

let polling = false;
let timer: NodeJS.Timeout | undefined;
let freshBaseline: string | null = null;
let providerCache: ProviderResult[] = [];
let providerNextAllowedAt = 0;
let providerLastSource: string | null = null;
let providerFailureBackoffMs = 2_000;
let snapshot: Wingo30sSnapshot = {
  connection: "STARTING", lastPollAt: null, source: null, baseline: null, nextIssue: null,
  actualCount: 0, prediction: null, recentResults: [], recentPredictions: [], error: null,
};

const normalize = (values: number[]) => {
  const safe = values.map(value => Math.max(0.0001, Number.isFinite(value) ? value : 0));
  const total = safe.reduce((sum, value) => sum + value, 0);
  return total ? safe.map(value => value / total) : Array.from({ length: 10 }, () => 0.1);
};
const countDigits = (values: number[]) => values.reduce((counts, value) => {
  if (Number.isInteger(value) && value >= 0 && value <= 9) counts[value] += 1;
  return counts;
}, Array(10).fill(0) as number[]);
const topDigit = (values: number[]) => values.reduce((best, value, index) => value > values[best] ? index : best, 0);
const sizeOf = (value: number): Size => value >= 5 ? "BIG" : "SMALL";
const issueSort = (a: { issue: string }, b: { issue: string }) => {
  try { return BigInt(a.issue) > BigInt(b.issue) ? -1 : BigInt(a.issue) < BigInt(b.issue) ? 1 : 0; }
  catch { return b.issue.localeCompare(a.issue); }
};
const issueGreater = (a: string, b: string) => { try { return BigInt(a) > BigInt(b); } catch { return a > b; } };
const nextIssue = (issue: string) => { try { return (BigInt(issue) + 1n).toString(); } catch { return issue; } };
const average = (vectors: number[][]) => normalize(Array.from({ length: 10 }, (_, digit) => vectors.reduce((sum, vector) => sum + vector[digit], 0)));

function frequency(values: number[], decay = 0) {
  const scores = Array(10).fill(0.01) as number[];
  values.forEach((value, index) => { if (scores[value] !== undefined) scores[value] += decay ? Math.exp(-index / decay) : 1; });
  return normalize(scores);
}
function transition(values: number[], order: number) {
  const scores = Array(10).fill(0.15) as number[];
  if (values.length <= order) return normalize(scores);
  const context = values.slice(0, order).join(",");
  for (let index = order; index < values.length; index += 1) {
    if (values.slice(index - order, index).reverse().join(",") === context) scores[values[index]] += 1;
  }
  return normalize(scores);
}
function gaps(values: number[]) {
  const last = Array(10).fill(values.length + 2) as number[];
  values.forEach((value, index) => { if (last[value] === values.length + 2) last[value] = index; });
  const recent = countDigits(values.slice(0, 40));
  return normalize(last.map((gap, digit) => Math.min(gap, 50) + recent[digit] * 0.15));
}
function fourier(values: number[]) {
  const output = Array(10).fill(0) as number[];
  for (let digit = 0; digit < 10; digit += 1) {
    for (let lag = 1; lag <= Math.min(20, values.length - 1); lag += 1) {
      let correlation = 0;
      for (let index = 0; index < values.length - lag; index += 1) if (values[index] === digit && values[index + lag] === digit) correlation += 1;
      output[digit] += correlation * Math.cos(2 * Math.PI * lag / Math.max(2, values.length));
    }
  }
  return normalize(output.map(value => Math.max(0.01, value + 0.1)));
}
function entropy(values: number[]) {
  const counts = countDigits(values);
  const length = Math.max(1, values.length);
  const probabilities = counts.map(value => value / length);
  const h = -probabilities.reduce((sum, value) => sum + (value ? value * Math.log(value) : 0), 0);
  return normalize(counts.map(value => 1 + value * (0.5 + h / Math.log(10))));
}
function wavelet(values: number[]) {
  const short = frequency(values.slice(0, Math.min(12, values.length)));
  const long = frequency(values.slice(0, Math.min(60, values.length)));
  return normalize(short.map((value, index) => Math.max(0.001, 0.55 * value + 0.45 * long[index] + 0.15 * Math.abs(value - long[index]))));
}

function engineScores(values: number[]) {
  const counts = countDigits(values);
  const recent = frequency(values.slice(0, 30), 18);
  const long = frequency(values.slice(0, 100));
  const m1 = transition(values, 1);
  const m2 = transition(values, 2);
  const m4 = transition(values, 4);
  const gap = gaps(values);
  const ent = entropy(values);
  const wave = wavelet(values);
  const four = fourier(values);
  const bayes = normalize(counts.map(value => value + 1.5));
  const xgb = normalize(counts.map((value, index) => 0.45 * value + 0.4 * recent[index] * Math.max(1, values.length) + 0.15 * long[index] * Math.max(1, values.length)));
  const rf = normalize(recent.map((value, index) => 0.5 * value + 0.3 * long[index] + 0.2 * m1[index]));
  const lstm = normalize(m1.map((value, index) => 0.55 * value + 0.3 * m2[index] + 0.15 * m4[index]));
  const parity = normalize(counts.map((value, digit) => value + ((digit % 2) === ((values[0] ?? 0) % 2) ? 0.8 : 0.35)));
  const neighbor = normalize(counts.map((value, digit) => value + ([((values[0] ?? 0) + 1) % 10, ((values[0] ?? 0) + 9) % 10].includes(digit) ? 1.4 : 0.1)));
  const volatility = normalize(counts.map((value, digit) => value + Math.abs((values[0] ?? 0) - digit) * 0.08 + (digit >= 5 ? 0.15 : 0)));
  const median = [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)] ?? 4.5;
  const medianBias = normalize(counts.map((value, digit) => value + Math.max(0.1, 1.2 - Math.abs(digit - median) * 0.18)));
  return [m1, m2, m4, bayes, ent, gap, normalize(counts.map(value => value + 1)), xgb, rf, lstm, wave, four, parity, neighbor, volatility, medianBias];
}

function patternScore(name: string, values: number[]) {
  const counts = countDigits(values);
  const recent = frequency(values.slice(0, Math.min(20, values.length)), 12);
  const long = frequency(values.slice(0, Math.min(80, values.length)));
  const m1 = transition(values, 1);
  const m2 = transition(values, 2);
  const m4 = transition(values, 4);
  const gap = gaps(values);
  const four = fourier(values);
  const wave = wavelet(values);
  const last = values[0] ?? 0;
  const previous = values[1] ?? last;
  const last3 = values.slice(0, 3);
  const last5 = values.slice(0, 5);
  const base = normalize(counts.map(value => value + 1));
  const same = base;
  const repeat = normalize(counts.map((value, digit) => value + (digit === last ? 1.5 : 0)));
  const reverse = normalize(counts.map((value, digit) => value + (digit === 9 - last ? 1.2 : 0)));
  const alternating = normalize(counts.map((value, digit) => value + (digit === (last3[2] ?? last) && digit !== last ? 1.3 : 0)));
  const ascending = normalize(counts.map((value, digit) => value + (digit === (last + 1) % 10 ? 1.6 : 0)));
  const descending = normalize(counts.map((value, digit) => value + (digit === (last + 9) % 10 ? 1.6 : 0)));
  const skip = normalize(counts.map((value, digit) => value + (digit === (last + 2) % 10 || digit === (last + 8) % 10 ? 1.2 : 0)));
  const pair = normalize(counts.map((value, digit) => value + (digit === (last + previous) % 10 ? 1.4 : 0)));
  const triple = normalize(counts.map((value, digit) => value + (digit === last3.reduce((sum, item) => sum + item, 0) % 10 ? 1.4 : 0)));
  const difference = normalize(counts.map((value, digit) => value + (digit === ((last5[0] ?? last) - (last5[1] ?? previous) + 10) % 10 ? 1.2 : 0)));
  const periodic = normalize(counts.map((value, digit) => value + (digit === last ? four[digit] * 2 : 0)));
  const anomaly = normalize(counts.map((value, digit) => value + (value === Math.min(...counts) ? 1 : 0)));
  const drift = normalize(recent.map((value, digit) => value - long[digit]));
  const multi = normalize(m1.map((value, digit) => value + m2[digit] + wave[digit]));
  const map: Record<string, number[]> = {
    Consecutive: m1, Reverse: reverse, Repeating: repeat, Alternating: alternating, Ascending: ascending, Descending: descending,
    "Skip Sequence": skip, "Broken Sequence": wave, "Short / Long Run": recent, "Immediate Repeat": repeat, "Delayed Repeat": gap,
    "Triple Repeat": triple, "Frequency Repeat": same, "Repeat Gap": gap, "Repeat Cycle": periodic, "Pair Transition": pair,
    "Triple Transition": triple, "4-Step Transition": m4, "5-Gram Transition": m4, "Conditional Transition": m2, "Markov Sequence": m1,
    "Reverse Transition": reverse, "Multi-Level Transition": multi, "Arithmetic Progression": difference, "Modular Arithmetic": skip,
    "Difference Sequence": difference, "Gap Distribution": gap, Periodicity: periodic, Autocorrelation: four, "Wavelet Scale": wave,
    "Frequency Spectrum": four, "Hidden State": normalize(m1.map((value, digit) => value + gap[digit])), "Latent Sequence": normalize(m2.map((value, digit) => value + wave[digit])),
    "Multi-Scale Pattern": normalize(recent.map((value, digit) => value + long[digit] + wave[digit])), "Nonlinear Change": drift,
    "Historical Similarity": long, "Pattern Change Detection": drift, "Cluster Sequence": normalize(counts.map((value, digit) => value + (digit < 5 ? 0.05 : 0))),
    "Anomaly Pattern": anomaly, "Pattern Frequency Validation": same, "Stability Test": normalize(same.map((value, digit) => value + long[digit])),
    "Out-of-Sample Test": long, "Significance Test": entropy(values), "False-Pattern Filter": normalize(same.map((value, digit) => 0.7 * value + 0.3 * entropy(values)[digit])),
    "Confidence Calibration": normalize(same.map((value, digit) => value + entropy(values)[digit])), "Pattern Ranking": normalize(same.map((value, digit) => value + recent[digit] * 0.4)),
    "Pattern Memory": long, "Pattern Evolution": normalize(long.map((value, digit) => value + drift[digit] * 0.5)),
    "Parity Flip": normalize(counts.map((value, digit) => value + (digit % 2 === (last % 2) ? 0.15 : 1.1))),
    "Parity Run": normalize(counts.map((value, digit) => value + (digit % 2 === (previous % 2) ? 1.1 : 0.2))),
    "High Low Balance": normalize(counts.map((value, digit) => value + (digit >= 5 ? 0.75 : 0.65))),
    "Digit Neighbor": normalize(counts.map((value, digit) => value + ([((last + 1) % 10), ((last + 9) % 10)].includes(digit) ? 1.4 : 0.1))),
    "Mirror Pair": reverse,
    "Center Bias": normalize(counts.map((value, digit) => value + Math.max(0.1, 1.2 - Math.abs(digit - 4.5) * 0.2))),
    "Edge Bias": normalize(counts.map((value, digit) => value + (digit === 0 || digit === 9 ? 1.1 : 0.2))),
    "Hot Cold Rotation": normalize(counts.map((value, digit) => value + (value <= Math.min(...counts) + 1 ? 1.2 : 0.2))),
    "Volatility Shift": normalize(counts.map((value, digit) => value + Math.abs((last - digit) % 10) * 0.08)),
    "Rolling Median": normalize(counts.map((value, digit) => value + Math.max(0.1, 1.2 - Math.abs(digit - ([...values].sort((a, b) => a - b)[Math.floor(values.length / 2)] ?? 4.5)) * 0.18))),
    Momentum: normalize(recent.map((value, digit) => value + (digit === last ? 0.8 : 0))),
    "Anti-Streak": normalize(counts.map((value, digit) => value + (digit === last ? 0.05 : 0.35))),
    "Last-Digit Echo": repeat,
    "Two-Window Drift": drift,
    "Recent Consensus": average([recent, m1, wave]),
    "Diversity Guard": normalize(counts.map(value => 1 / (value + 1))),
  };
  return normalize((map[name] ?? base).map(value => Math.max(0.0001, value)));
}

function analyse(values: number[]) {
  const models = engineScores(values);
  const coreWeights = [1.15, 1, 0.9, 0.75, 0.7, 0.55, 0.65, 0.5, 0.5, 0.55, 0.35, 0.3, 0.45, 0.42, 0.38, 0.4];
  const total = Array(10).fill(0) as number[];
  models.forEach((vector, index) => vector.forEach((value, digit) => { total[digit] += value * coreWeights[index]; }));
  const branches = [
    average(models.slice(0, 3)),
    normalize(countDigits(values).map(value => value + 1.5)),
    average(models.slice(3)),
    normalize(total),
    average(models.slice(0, 6)),
    normalize(countDigits(values).map(value => 1 / (value + 1))),
    average(models.slice(8, 16)),
    average([models[12], models[13], models[15]]),
  ];
  branches.forEach((vector, index) => vector.forEach((value, digit) => { total[digit] += value * [0.8, 0.65, 0.7, 1.25, 0.55, 0.4, 0.5, 0.45][index]; }));
  const patterns = PATTERNS.map(name => ({ name, vector: patternScore(name, values) }));
  const patternBlend = average(patterns.map(item => item.vector));
  patternBlend.forEach((value, digit) => { total[digit] += value * 0.9; });
  const scores = normalize(total);
  const rank = scores.map((score, digit) => ({ score, digit })).sort((a, b) => b.score - a.score);
  const chosen = rank[0].digit;
  const voteSources = [...models, ...branches, ...patterns.map(item => item.vector)];
  const votes = Array(10).fill(0) as number[];
  voteSources.forEach(vector => { votes[topDigit(vector)] += 1; });
  const chosenVotes = votes[chosen];
  const predictedSize = sizeOf(chosen);
  const sizeVotes = voteSources.filter(vector => sizeOf(topDigit(vector)) === predictedSize).length;
  const margin = rank[0].score - rank[1].score;
  const voteRatio = chosenVotes / voteSources.length;
  const confidence = values.length < 10 ? "INSUFFICIENT DATA" : voteRatio >= 0.7 && margin >= 0.03 ? "HIGH CONFIRMATION" : voteRatio >= 0.55 ? "MEDIUM CONFIRMATION" : "LOW CONFIRMATION";
  return {
    prediction: chosen, predictionSize: predictedSize, inputCount: values.length, chosenVotes, totalVotes: voteSources.length,
    coreVotes: models.filter(vector => topDigit(vector) === chosen).length,
    aiVotes: branches.filter(vector => topDigit(vector) === chosen).length,
    patternVotes: patterns.filter(item => topDigit(item.vector) === chosen).length,
    sizeVotes, confidence, marginBps: Math.round(margin * 10000), rank, patterns, scores,
  };
}

function parseProvider(payload: any): ProviderResult[] {
  const list = payload?.recentResults ?? payload?.data?.list ?? payload?.data?.data ?? (Array.isArray(payload?.data) ? payload.data : null) ?? payload?.list ?? [];
  return list.map((item: any) => ({
    issue: String(item.issueNumber ?? item.issue ?? item.period ?? item.id ?? ""),
    number: Number(item.number ?? item.openNumber ?? item.result),
  })).filter((item: ProviderResult) => item.issue && Number.isInteger(item.number) && item.number >= 0 && item.number <= 9);
}

async function fetchLatest(): Promise<{ results: ProviderResult[]; source: string; cached: boolean }> {
  if (providerCache.length && Date.now() < providerNextAllowedAt) {
    return { results: providerCache, source: `${providerLastSource ?? ENDPOINTS[0]} (cached)`, cached: true };
  }
  const failures: string[] = [];
  for (const baseEndpoint of ENDPOINTS) {
    const endpoint = `${baseEndpoint}${baseEndpoint.includes("?") ? "&" : "?"}ts=${Date.now()}`;
    try {
      const response = await fetch(endpoint, {
        cache: "no-store",
        headers: { Accept: "application/json, text/plain, */*", "Accept-Language": "en-US,en;q=0.9", Referer: baseEndpoint.includes(PROVIDED_SERVER) ? `https://${PROVIDED_SERVER}/wingo-30s` : "https://draw.ar-lottery01.com/", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36", ...(baseEndpoint.includes(PROVIDED_SERVER) ? { Cookie: PROVIDED_SERVER_COOKIE } : {}) },
        signal: AbortSignal.timeout(3_000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const results = parseProvider(await response.json()).sort(issueSort).slice(0, 100);
      if (!results.length) throw new Error("Empty provider result list");
      providerCache = results;
      providerLastSource = endpoint;
      providerFailureBackoffMs = 2_000;
      providerNextAllowedAt = Date.now() + PROVIDER_MIN_INTERVAL_MS;
      return { results, source: endpoint, cached: false };
    } catch (error) {
      const reason = error instanceof Error ? error.message : "request failed";
      failures.push(`${baseEndpoint}: ${reason}`);
      console.warn(`[Wingo30s] Provider request failed for ${baseEndpoint}:`, reason);
    }
  }
  providerNextAllowedAt = Date.now() + providerFailureBackoffMs;
  providerFailureBackoffMs = Math.min(providerFailureBackoffMs * 2, 30_000);
  if (providerCache.length) {
    return { results: providerCache, source: `${providerLastSource ?? ENDPOINTS[0]} (cached after provider error)`, cached: true };
  }
  return { results: [], source: `Provider unavailable (${failures.join(" | ")})`, cached: true };
}

async function rebuildSnapshot() {
  const results = (await listWingo30sResults()).sort(issueSort);
  const predictions = await listWingo30sPredictions(5000);
  const newest = results[0];
  const target = newest ? nextIssue(newest.issue) : null;
  const prediction = target ? (await getWingo30sPrediction(target)) ?? null : null;
  snapshot = {
    ...snapshot,
    baseline: freshBaseline,
    nextIssue: target,
    actualCount: results.length,
    prediction,
    recentResults: results.slice(0, 20),
    recentPredictions: predictions,
  };
}

async function ensureNextPrediction(actuals: { issue: string; number: number }[]) {
  const newest = actuals[0];
  if (!newest) return;
  const values = actuals.map(item => item.number);
  const target = nextIssue(newest.issue);
  const existing = await getWingo30sPrediction(target);
  if (existing && existing.inputCount === values.length) return;
  const result = analyse(values);
  await upsertWingo30sPrediction({
    issue: target,
    prediction: result.prediction,
    predictionSize: result.predictionSize,
    inputCount: result.inputCount,
    chosenVotes: result.chosenVotes,
    totalVotes: result.totalVotes,
    coreVotes: result.coreVotes,
    aiVotes: result.aiVotes,
    patternVotes: result.patternVotes,
    sizeVotes: result.sizeVotes,
    confidence: result.confidence,
    marginBps: result.marginBps,
    analyzedAt: new Date(),
  });
}

export async function syncWingo30s() {
  if (polling) return snapshot;
  polling = true;
  try {
    const persisted = await getWingo30sServiceState();
    freshBaseline = persisted?.freshBaseline ?? freshBaseline;
    const { results, source, cached } = await fetchLatest();
    const incoming = freshBaseline ? results.filter(item => issueGreater(item.issue, freshBaseline!)) : results;
    if (incoming.length === 0) {
      const actuals = (await listWingo30sResults()).sort(issueSort);
      await ensureNextPrediction(actuals);
      snapshot = { ...snapshot, connection: actuals.length ? (freshBaseline ? "FRESH" : "LIVE") : "ERROR", source, lastPollAt: new Date().toISOString(), error: actuals.length && cached ? "Provider temporarily unavailable; last confirmed results retained and analysis continues from durable history." : actuals.length ? null : "Waiting for the first confirmed provider result.", baseline: freshBaseline };
      await rebuildSnapshot();
      return snapshot;
    }
    for (const item of incoming) {
      await upsertWingo30sResult(item.issue, item.number);
      await resolveWingo30sPrediction(item.issue, item.number);
    }
    const actuals = (await listWingo30sResults()).sort(issueSort);
    await ensureNextPrediction(actuals);
    snapshot = { ...snapshot, connection: "LIVE", source, lastPollAt: new Date().toISOString(), error: cached ? "Provider temporarily rate-limited; last confirmed results retained." : null, baseline: freshBaseline };
    await rebuildSnapshot();
  } catch (error) {
    console.warn("[Wingo30s] Poll failed:", error instanceof Error ? error.message : error);
    const actuals = (await listWingo30sResults()).sort(issueSort);
    if (actuals.length) await ensureNextPrediction(actuals);
    snapshot = { ...snapshot, connection: actuals.length ? "LIVE" : "ERROR", lastPollAt: new Date().toISOString(), error: actuals.length ? "Worker recovered using durable history; provider retry remains active." : error instanceof Error ? error.message : "Wingo30s polling failed" };
    await rebuildSnapshot();
  } finally { polling = false; }
  return snapshot;
}

export async function freshStart() {
  const current = (await listWingo30sResults()).sort(issueSort);
  let baseline: string | null = current[0]?.issue ?? null;
  if (!baseline) {
    try { baseline = (await fetchLatest()).results[0]?.issue ?? null; } catch { baseline = null; }
  }
  await clearWingo30sHistory();
  freshBaseline = baseline;
  await setWingo30sFreshBaseline(baseline);
  snapshot = { ...snapshot, connection: "FRESH", baseline, nextIssue: null, actualCount: 0, prediction: null, recentResults: [], recentPredictions: [], error: null };
  return snapshot;
}

export async function getWingo30sSnapshot() {
  if (!snapshot.lastPollAt) await rebuildSnapshot();
  return snapshot;
}

export function startWingo30sWorker() {
  if (timer) return;
  void syncWingo30s();
  timer = setInterval(() => void syncWingo30s(), POLL_MS);
  console.log(`[Wingo30s] Always-on worker started; polling every ${POLL_MS}ms`);
}
