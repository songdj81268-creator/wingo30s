import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { freshStart as freshStart30s, getWingo30sSnapshot, startWingo30sWorker } from "../wingo30sService";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", async (_req, res) => {
    const wingo30s = await getWingo30sSnapshot();
    res.json({ status: "ok", service: "wingo-30s-standalone", connection: wingo30s.connection, lastPollAt: wingo30s.lastPollAt, actualCount: wingo30s.actualCount, nextIssue: wingo30s.nextIssue });
  });
  app.get("/api/wingo30s/state", async (_req, res) => res.json(await getWingo30sSnapshot()));
  app.get("/api/wingo30s/health", async (_req, res) => {
    const wingo30s = await getWingo30sSnapshot();
    res.json({ status: "ok", service: "wingo-30s-independent", connection: wingo30s.connection, lastPollAt: wingo30s.lastPollAt, actualCount: wingo30s.actualCount, nextIssue: wingo30s.nextIssue });
  });
  app.post("/api/wingo30s/fresh-start", async (_req, res) => res.json(await freshStart30s()));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => {
    console.log(`Server listening on port ${port}`);
    startWingo30sWorker();
  });
}

startServer().catch(error => { console.error(error); process.exit(1); });
