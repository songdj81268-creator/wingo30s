import { and, asc, desc, eq, gt, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, User, users, wingoPredictions, wingoResults, wingoServiceState, wingo30sPredictions, wingo30sResults, wingo30sServiceState } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  const dbUser = db as any;
  await dbUser.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listWingoResults() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(wingoResults).orderBy(desc(wingoResults.observedAt));
}

export async function upsertWingoResult(issue: string, number: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(wingoResults).values({ issue, number }).onDuplicateKeyUpdate({ set: { number, observedAt: new Date() } });
}

export async function listWingoPredictions(limit = 150) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(wingoPredictions).orderBy(desc(wingoPredictions.analyzedAt)).limit(limit);
}

export async function getWingoPrediction(issue: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(wingoPredictions).where(eq(wingoPredictions.issue, issue)).limit(1);
  return result[0];
}

export type WingoPredictionInsert = typeof wingoPredictions.$inferInsert;
export async function upsertWingoPrediction(value: WingoPredictionInsert) {
  const db = await getDb();
  if (!db) return;
  await db.insert(wingoPredictions).values(value).onDuplicateKeyUpdate({
    set: {
      prediction: value.prediction,
      predictionSize: value.predictionSize,
      inputCount: value.inputCount,
      chosenVotes: value.chosenVotes,
      totalVotes: value.totalVotes,
      coreVotes: value.coreVotes,
      aiVotes: value.aiVotes,
      patternVotes: value.patternVotes,
      sizeVotes: value.sizeVotes,
      confidence: value.confidence,
      marginBps: value.marginBps,
      analyzedAt: value.analyzedAt,
    },
  });
}

export async function resolveWingoPrediction(issue: string, result: number) {
  const db = await getDb();
  if (!db) return;
  const prediction = await getWingoPrediction(issue);
  if (!prediction) return;
  const resultSize = result >= 5 ? "BIG" : "SMALL";
  await db.update(wingoPredictions).set({
    result,
    resultSize,
    sizeStatus: prediction.predictionSize === resultSize ? "PASS" : "MISS",
    jackpot: prediction.prediction === result ? 1 : 0,
    resolvedAt: new Date(),
  }).where(eq(wingoPredictions.issue, issue));
}

export async function getWingoServiceState() {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(wingoServiceState).where(eq(wingoServiceState.id, 1)).limit(1);
  return result[0];
}

export async function setWingoFreshBaseline(freshBaseline: string | null) {
  const db = await getDb();
  if (!db) return;
  await db.insert(wingoServiceState).values({ id: 1, freshBaseline }).onDuplicateKeyUpdate({ set: { freshBaseline, updatedAt: new Date() } });
}

export async function clearWingoHistory() {
  const db = await getDb();
  if (!db) return;
  await db.delete(wingoPredictions);
  await db.delete(wingoResults);
}

export async function listWingo30sResults() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(wingo30sResults).orderBy(desc(wingo30sResults.observedAt));
}
export async function upsertWingo30sResult(issue: string, number: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(wingo30sResults).values({ issue, number }).onDuplicateKeyUpdate({ set: { number, observedAt: new Date() } });
  // Periods are monotonically increasing; ascending issue order guarantees that
  // only the first/oldest 100 periods are removed, never a middle segment.
  const rows = await db.select({ issue: wingo30sResults.issue }).from(wingo30sResults).orderBy(asc(wingo30sResults.issue));
  if (rows.length >= 4998) {
    const staleIssues = rows.slice(0, 100).map(row => row.issue);
    await db.delete(wingo30sPredictions).where(inArray(wingo30sPredictions.issue, staleIssues));
    await db.delete(wingo30sResults).where(inArray(wingo30sResults.issue, staleIssues));
  }
}
export async function listWingo30sPredictions(limit = 5000) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(wingo30sPredictions).orderBy(desc(wingo30sPredictions.analyzedAt)).limit(limit);
}
export async function getWingo30sPrediction(issue: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(wingo30sPredictions).where(eq(wingo30sPredictions.issue, issue)).limit(1);
  return result[0];
}
export type Wingo30sPredictionInsert = typeof wingo30sPredictions.$inferInsert;
export async function upsertWingo30sPrediction(value: Wingo30sPredictionInsert) {
  const db = await getDb();
  if (!db) return;
  await db.insert(wingo30sPredictions).values(value).onDuplicateKeyUpdate({ set: {
    prediction: value.prediction, predictionSize: value.predictionSize, inputCount: value.inputCount,
    chosenVotes: value.chosenVotes, totalVotes: value.totalVotes, coreVotes: value.coreVotes, aiVotes: value.aiVotes,
    patternVotes: value.patternVotes, sizeVotes: value.sizeVotes, confidence: value.confidence, marginBps: value.marginBps,
    analyzedAt: value.analyzedAt,
  }});
  const rows = await db.select({ issue: wingo30sPredictions.issue }).from(wingo30sPredictions).orderBy(asc(wingo30sPredictions.issue));
  if (rows.length >= 4998) {
    const staleIssues = rows.slice(0, 100).map(row => row.issue);
    await db.delete(wingo30sPredictions).where(inArray(wingo30sPredictions.issue, staleIssues));
  }
}
export async function resolveWingo30sPrediction(issue: string, result: number) {
  const db = await getDb();
  if (!db) return;
  const prediction = await getWingo30sPrediction(issue);
  if (!prediction) return;
  const resultSize = result >= 5 ? "BIG" : "SMALL";
  await db.update(wingo30sPredictions).set({ result, resultSize, sizeStatus: prediction.predictionSize === resultSize ? "PASS" : "MISS", jackpot: prediction.prediction === result ? 1 : 0, resolvedAt: new Date() }).where(eq(wingo30sPredictions.issue, issue));
}
export async function getWingo30sServiceState() {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(wingo30sServiceState).where(eq(wingo30sServiceState.id, 1)).limit(1);
  return result[0];
}
export async function setWingo30sFreshBaseline(freshBaseline: string | null) {
  const db = await getDb();
  if (!db) return;
  await db.insert(wingo30sServiceState).values({ id: 1, freshBaseline }).onDuplicateKeyUpdate({ set: { freshBaseline, updatedAt: new Date() } });
}
export async function clearWingo30sHistory() {
  const db = await getDb();
  if (!db) return;
  await db.delete(wingo30sPredictions);
  await db.delete(wingo30sResults);
}
