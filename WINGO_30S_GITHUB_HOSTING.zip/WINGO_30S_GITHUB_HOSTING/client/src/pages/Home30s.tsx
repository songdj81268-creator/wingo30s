import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Activity, AlertTriangle, CheckCircle2, Database, RefreshCw, RotateCcw, Server, ShieldCheck, Sparkles, Trophy, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";

type Size = "BIG" | "SMALL";
type Prediction = {
  issue: string;
  prediction: number;
  predictionSize: Size;
  inputCount: number;
  chosenVotes: number;
  totalVotes: number;
  coreVotes: number;
  aiVotes: number;
  patternVotes: number;
  sizeVotes: number;
  confidence: string;
  marginBps: number;
  result: number | null;
  resultSize: Size | null;
  sizeStatus: "PASS" | "MISS" | null;
  jackpot: number;
  analyzedAt: string;
  resolvedAt: string | null;
};
type Snapshot = {
  connection: "LIVE" | "ERROR" | "STARTING" | "FRESH";
  lastPollAt: string | null;
  source: string | null;
  baseline: string | null;
  nextIssue: string | null;
  actualCount: number;
  prediction: Prediction | null;
  recentResults: { issue: string; number: number; observedAt: string }[];
  recentPredictions: Prediction[];
  error: string | null;
};

const empty: Snapshot = {
  connection: "STARTING", lastPollAt: null, source: null, baseline: null, nextIssue: null,
  actualCount: 0, prediction: null, recentResults: [], recentPredictions: [], error: null,
};
const formatTime = (value: string | null) => value ? new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "—";
const sizeClass = (size: Size | null | undefined) => size === "BIG" ? "big" : "small";

export default function Home30s() {
  const [data, setData] = useState<Snapshot>(empty);
  const [loading, setLoading] = useState(true);
  const [freshLoading, setFreshLoading] = useState(false);
  const requestInFlight = useRef(false);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const audioContext = useRef<AudioContext | null>(null);
  const lastSoundKey = useRef("");
  const previousIssue = useRef<string | null>(null);

  const load = useCallback(async () => {
    if (requestInFlight.current) return;
    requestInFlight.current = true;
    try {
      const response = await fetch("/api/wingo30s/state", { cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      setData(await response.json());
    } catch (error) {
      setData(current => ({ ...current, connection: "ERROR", error: error instanceof Error ? error.message : "Dashboard request failed" }));
    } finally { requestInFlight.current = false; setLoading(false); }
  }, []);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => void load(), 50);
    return () => window.clearInterval(timer);
  }, [load]);

  const playBass = useCallback((frequency: number, duration = 0.22, volume = 0.13) => {
    if (!soundEnabled) return;
    const AudioCtor = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtor) return;
    audioContext.current ??= new AudioCtor();
    const context = audioContext.current;
    void context.resume();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const now = context.currentTime;
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(frequency, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(45, frequency * 0.72), now + duration);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    oscillator.connect(gain).connect(context.destination);
    oscillator.start(now);
    oscillator.stop(now + duration + 0.03);
  }, [soundEnabled]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      const seconds = Math.floor(Date.now() / 1000) % 30;
      const remaining = seconds === 0 ? 30 : 30 - seconds;
      setCountdown(remaining);
      if (soundEnabled && remaining <= 5 && remaining >= 1) {
        const key = `${data.nextIssue ?? "waiting"}:${remaining}`;
        if (key !== lastSoundKey.current) {
          lastSoundKey.current = key;
          playBass(remaining === 1 ? 180 : 330, remaining === 1 ? 0.32 : 0.13, remaining === 1 ? 0.2 : 0.1);
        }
      }
      if (soundEnabled && data.nextIssue && previousIssue.current && previousIssue.current !== data.nextIssue) playBass(72, 0.42, 0.22);
      if (data.nextIssue) previousIssue.current = data.nextIssue;
    }, 100);
    return () => window.clearInterval(timer);
  }, [data.nextIssue, playBass, soundEnabled]);

  const toggleSound = () => {
    if (!soundEnabled) {
      const AudioCtor = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioCtor) {
        audioContext.current ??= new AudioCtor();
        void audioContext.current.resume();
      }
      setSoundEnabled(true);
    } else {
      setSoundEnabled(false);
    }
  };

  const startFresh = async () => {
    if (!window.confirm("Delete all stored Wingo results and predictions, then wait for only the next new result?")) return;
    setFreshLoading(true);
    try {
      const response = await fetch("/api/wingo30s/fresh-start", { method: "POST" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      setData(await response.json());
    } catch (error) {
      setData(current => ({ ...current, error: error instanceof Error ? error.message : "Fresh Start failed" }));
    } finally { setFreshLoading(false); }
  };

  const p = data.prediction;
  const resolved = useMemo(() => data.recentPredictions.filter(item => item.result !== null), [data.recentPredictions]);
  const sizePass = resolved.length ? Math.round(resolved.filter(item => item.sizeStatus === "PASS").length / resolved.length * 100) : null;
  const jackpots = resolved.filter(item => item.jackpot === 1).length;
  const connectionLabel = data.connection === "LIVE" ? "LIVE SOURCE CONNECTED" : data.connection === "FRESH" ? "FRESH START ACTIVE" : data.connection === "ERROR" ? "SOURCE ERROR" : "STARTING WORKER";

  return (
    <main className="wingo-shell">
      <div className="wingo-frame">
        <header className="hero-card">
          <div className="hero-kicker"><Activity size={15} /> INDEPENDENT 24/7 WORKER • WINGO 30-SEC</div>
          <div className="hero-title">亗 『KH』 VIP <span>LIVE AI</span> 亗</div>
          <p>Separate 30-sec source, worker, database history and full-vote analysis</p>
        </header>

        <section className="status-strip">
          <span className={`status-dot ${data.connection.toLowerCase()}`} />
          <strong>{connectionLabel}</strong>
          <span>UI refresh: 0.1s</span>
          <span>Provider check: 5s</span>
          <span>Last poll: {formatTime(data.lastPollAt)}</span>
        </section>

        {data.error && data.connection !== "LIVE" && <div className="warning"><AlertTriangle size={16} /> {data.error}</div>}

        <section className="prediction-card">
          <div className="eyebrow">NEXT PERIOD ANALYSIS</div>
          <div className="next-issue">PERIOD {data.nextIssue ?? "—"}</div>
          <div className="prediction-number">{p?.prediction ?? "–"}</div>
          <div className={`prediction-size ${sizeClass(p?.predictionSize)}`}>{p?.predictionSize ?? "WAITING"}</div>
          <div className="period-countdown">NEXT PERIOD IN <strong>00:{String(countdown).padStart(2, "0")}</strong></div>
          <div className="prediction-caption">SERVER-SIDE CUMULATIVE PREDICTION</div>
          {p && <div className="prediction-note">Analysed on all {p.inputCount} accepted results • {p.confidence}</div>}
        </section>

        <section className="confirmation-card">
          <div className="section-heading"><ShieldCheck size={18} /> FULL CONFIRMATION • ALL ACTIVE VOTES</div>
          {p ? <div className="confirmation-grid">
            <Metric label="NUMBER VOTES" value={`${p.chosenVotes}/${p.totalVotes}`} accent />
            <Metric label="CORE ENGINES" value={`${p.coreVotes}/16`} />
            <Metric label="AI BRANCHES" value={`${p.aiVotes}/8`} />
            <Metric label="PATTERNS" value={`${p.patternVotes}/64`} />
            <Metric label="SIZE VOTES" value={`${p.predictionSize} ${p.sizeVotes}/${p.totalVotes}`} />
            <Metric label="TOP-2 MARGIN" value={`${(p.marginBps / 100).toFixed(2)}%`} />
          </div> : <div className="empty-state">{loading ? "Connecting to the always-on worker…" : "Waiting for the first eligible result."}</div>}
          <div className="audit-row"><span><CheckCircle2 size={14} /> 15/15 support audits</span><span><CheckCircle2 size={14} /> 10/10 master audits</span><span><Sparkles size={14} /> 88 numeric votes</span></div>
        </section>

        <section className="control-row">
          <Button variant="outline" onClick={() => void load()}><RefreshCw size={16} /> Refresh view</Button>
          <Button variant="outline" onClick={toggleSound}>{soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />} {soundEnabled ? "BASS SOUND ON" : "BASS SOUND"}</Button>
          <Button variant="destructive" onClick={() => void startFresh()} disabled={freshLoading}><RotateCcw size={16} /> {freshLoading ? "Starting…" : "Delete old • Start fresh"}</Button>
        </section>

        <section className="stats-grid">
          <StatCard icon={<Database size={18} />} label="ACCEPTED RESULTS" value={`${data.actualCount} / 5000`} detail="Rolling history; oldest 100 auto-delete at 4998" />
          <StatCard icon={<Trophy size={18} />} label="JACKPOTS" value={String(jackpots)} detail={resolved.length ? `${resolved.length} resolved predictions` : "No resolved periods yet"} />
          <StatCard icon={<CheckCircle2 size={18} />} label="SIZE PASS" value={sizePass === null ? "—" : `${sizePass}%`} detail="BIG/SMALL only" />
          <StatCard icon={<Server size={18} />} label="UI REFRESH" value="0.1s" detail="Browser 0.05s • worker 0.25s • provider 5s" />
        </section>

        <section className="history-card">
          <div className="section-heading"><Database size={18} /> ALL PREDICTIONS & RESULTS <span className="history-count">{data.recentPredictions.length}</span></div>
          <div className="table-wrap"><table><thead><tr><th>PERIOD</th><th>PRED</th><th>SIZE</th><th>RESULT</th><th>SIZE CHECK</th><th>NUMBER</th><th>INPUT</th></tr></thead><tbody>
            {data.recentPredictions.length === 0 ? <tr><td colSpan={7} className="empty-cell">No prediction snapshot yet.</td></tr> : data.recentPredictions.map(item => <tr key={item.issue} className={item.jackpot === 1 || item.sizeStatus === "PASS" ? "history-row win" : item.sizeStatus === "MISS" ? "history-row loss" : "history-row pending"}>
              <td className="period-cell">{item.issue}</td><td className="number-cell">{item.prediction}</td><td><span className={`pill ${sizeClass(item.predictionSize)}`}>{item.predictionSize}</span></td><td>{item.result ?? "PENDING"}</td><td className={item.sizeStatus === "PASS" ? "pass" : item.sizeStatus === "MISS" ? "miss" : "muted"}>{item.sizeStatus ?? "PENDING"}</td><td className={item.jackpot ? "jackpot" : "muted"}>{item.jackpot ? "JACKPOT" : item.result === null ? "—" : "MISS"}</td><td>{item.inputCount}</td>
            </tr>)}
          </tbody></table></div>
        </section>

        <footer className="footer-note"><AlertTriangle size={13} /> Statistical ranking tool only. Random draws can be independent; confirmations are diagnostics, not guaranteed outcomes.</footer>
      </div>
    </main>
  );
}

function Metric({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return <div className={`metric ${accent ? "accent" : ""}`}><span>{label}</span><strong>{value}</strong></div>;
}
function StatCard({ icon, label, value, detail }: { icon: ReactNode; label: string; value: string; detail: string }) {
  return <div className="stat-card"><div className="stat-icon">{icon}</div><span>{label}</span><strong>{value}</strong><small>{detail}</small></div>;
}
