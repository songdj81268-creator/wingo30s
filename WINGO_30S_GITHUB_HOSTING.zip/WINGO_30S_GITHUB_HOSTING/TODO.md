# Wingo Live 1-Min AI — outcomes

- [ ] Latest-10 bootstrap: on normal service start, fetch and display the latest 10 Wingo 1-minute results.
- [ ] Continuous worker: keep polling the provider on the server at a fixed interval without requiring an open browser tab.
- [ ] Durable ingestion: save every accepted period once, update provider corrections by period ID, and retain history across process restarts.
- [ ] Cumulative analysis: use all accepted results for each new next-period prediction and expose the actual input count.
- [ ] Full numeric ensemble: run 12 core, 4 AI/master, and 48 active pattern vote vectors; show the vote breakdown and confidence diagnostics.
- [ ] BIG/SMALL: classify 0–4 as SMALL and 5–9 as BIG; mark size predictions PASS or MISS when resolved.
- [ ] JACKPOT: mark exact number matches as JACKPOT and keep exact-number metrics separate from size metrics.
- [ ] Fresh Start: delete stored app history, establish a baseline, ignore older provider history, and wait for the next new period.
- [ ] Live dashboard: display connection/worker status, next period, prediction, confirmation summary, saved count, accuracy, and recent history.
- [ ] Production readiness: health route, typecheck, build, local runtime smoke test, checkpoint, and publish configuration.
