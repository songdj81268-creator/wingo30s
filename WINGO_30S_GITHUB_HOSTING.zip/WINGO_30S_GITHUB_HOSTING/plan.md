# Wingo Live 1-Min AI — implementation plan

## Product scope

Build a continuously available Wingo 1-minute analysis service. The server polls the configured Wingo result source, imports the latest 10 results on a normal first run, stores each accepted period exactly once, cumulatively analyses all accepted results for the next period, and exposes a dashboard that refreshes without manual reload. The dashboard shows the selected number, BIG/SMALL class, PASS/MISS size checks, exact-number JACKPOT labels, cumulative count, full confirmation votes, and a Fresh Start action that deletes the app's stored history and ignores provider periods at or before the reset baseline.

## Architecture

- `server/wingoService.ts`: provider fetch, duplicate-safe ingestion, Fresh Start baseline, deterministic number/pattern ensemble, periodic polling, and state snapshots.
- `drizzle/schema.ts` and `server/db.ts`: durable results, predictions, and singleton service state in the managed MySQL database.
- `server/_core/index.ts`: health endpoint plus read/reset REST endpoints for the dashboard.
- `client/src/pages/Home.tsx`: dark compact live dashboard with polling status, prediction card, confirmation summary, history table, and Fresh Start control.
- `client/src/index.css`: dashboard visual system and responsive layout.

## Analysis contract

The service uses 12 core score branches, 4 AI/master branches, and 48 active pattern vectors for 64 numeric votes. Supporting and master audit checks remain transparent audit counts rather than invented numeric votes. Number class is 0–4 SMALL and 5–9 BIG. The model is explicitly a heuristic statistical ranking tool, not a guaranteed lottery predictor.

## Persistence and runtime

The worker starts with the server, polls every five seconds, and does not depend on a browser tab. All actual results and prediction snapshots are stored in the managed database. The service remains safe across process restarts because the next prediction is recomputed from database state. Published always-on hosting will be requested separately after implementation and publication configuration is ready.

## Design direction

Three candidate styles: neon control-room dashboard (0.07), quiet terminal observatory (0.06), and glass analytics lab (0.05). Choose neon control-room dashboard: near-black canvas, red/blue/gold signal colors, dense but readable evidence cards, and a bright prediction focal point. Use restrained glow, compact mobile-first panels, and explicit confidence language rather than hype.
