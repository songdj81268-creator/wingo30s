CREATE TABLE `wingo_30s_predictions` (
	`issue` varchar(64) NOT NULL,
	`prediction` int NOT NULL,
	`predictionSize` enum('BIG','SMALL') NOT NULL,
	`inputCount` int NOT NULL,
	`chosenVotes` int NOT NULL,
	`totalVotes` int NOT NULL,
	`coreVotes` int NOT NULL,
	`aiVotes` int NOT NULL,
	`patternVotes` int NOT NULL,
	`sizeVotes` int NOT NULL,
	`confidence` varchar(32) NOT NULL,
	`marginBps` int NOT NULL,
	`result` int,
	`resultSize` enum('BIG','SMALL'),
	`sizeStatus` enum('PASS','MISS'),
	`jackpot` int NOT NULL DEFAULT 0,
	`analyzedAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	CONSTRAINT `wingo_30s_predictions_issue` PRIMARY KEY(`issue`)
);
--> statement-breakpoint
CREATE TABLE `wingo_30s_results` (
	`issue` varchar(64) NOT NULL,
	`number` int NOT NULL,
	`observedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wingo_30s_results_issue` PRIMARY KEY(`issue`)
);
--> statement-breakpoint
CREATE TABLE `wingo_30s_service_state` (
	`id` int NOT NULL,
	`freshBaseline` varchar(64),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wingo_30s_service_state_id` PRIMARY KEY(`id`)
);
