import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const wingoResults = mysqlTable("wingo_results", {
  issue: varchar("issue", { length: 64 }).primaryKey(),
  number: int("number").notNull(),
  observedAt: timestamp("observedAt").defaultNow().notNull(),
});

export const wingoPredictions = mysqlTable("wingo_predictions", {
  issue: varchar("issue", { length: 64 }).primaryKey(),
  prediction: int("prediction").notNull(),
  predictionSize: mysqlEnum("predictionSize", ["BIG", "SMALL"]).notNull(),
  inputCount: int("inputCount").notNull(),
  chosenVotes: int("chosenVotes").notNull(),
  totalVotes: int("totalVotes").notNull(),
  coreVotes: int("coreVotes").notNull(),
  aiVotes: int("aiVotes").notNull(),
  patternVotes: int("patternVotes").notNull(),
  sizeVotes: int("sizeVotes").notNull(),
  confidence: varchar("confidence", { length: 32 }).notNull(),
  marginBps: int("marginBps").notNull(),
  result: int("result"),
  resultSize: mysqlEnum("resultSize", ["BIG", "SMALL"]),
  sizeStatus: mysqlEnum("sizeStatus", ["PASS", "MISS"]),
  jackpot: int("jackpot").notNull().default(0),
  analyzedAt: timestamp("analyzedAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export const wingoServiceState = mysqlTable("wingo_service_state", {
  id: int("id").primaryKey(),
  freshBaseline: varchar("freshBaseline", { length: 64 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const wingo30sResults = mysqlTable("wingo_30s_results", {
  issue: varchar("issue", { length: 64 }).primaryKey(),
  number: int("number").notNull(),
  observedAt: timestamp("observedAt").defaultNow().notNull(),
});

export const wingo30sPredictions = mysqlTable("wingo_30s_predictions", {
  issue: varchar("issue", { length: 64 }).primaryKey(),
  prediction: int("prediction").notNull(),
  predictionSize: mysqlEnum("predictionSize", ["BIG", "SMALL"]).notNull(),
  inputCount: int("inputCount").notNull(),
  chosenVotes: int("chosenVotes").notNull(),
  totalVotes: int("totalVotes").notNull(),
  coreVotes: int("coreVotes").notNull(),
  aiVotes: int("aiVotes").notNull(),
  patternVotes: int("patternVotes").notNull(),
  sizeVotes: int("sizeVotes").notNull(),
  confidence: varchar("confidence", { length: 32 }).notNull(),
  marginBps: int("marginBps").notNull(),
  result: int("result"),
  resultSize: mysqlEnum("resultSize", ["BIG", "SMALL"]),
  sizeStatus: mysqlEnum("sizeStatus", ["PASS", "MISS"]),
  jackpot: int("jackpot").notNull().default(0),
  analyzedAt: timestamp("analyzedAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export const wingo30sServiceState = mysqlTable("wingo_30s_service_state", {
  id: int("id").primaryKey(),
  freshBaseline: varchar("freshBaseline", { length: 64 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type WingoResult = typeof wingoResults.$inferSelect;
export type WingoPrediction = typeof wingoPredictions.$inferSelect;
