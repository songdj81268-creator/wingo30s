# Wingo 30-Sec Live AI — GitHub-ready package

This ZIP is the standalone Wingo 30-second application. It contains only the 30-second dashboard route, worker APIs, durable database helpers, live provider integration, 16 statistical engines, 8 AI voting branches, 64 pattern analyzers, and 5,000-result rolling retention. When the result count reaches 4,998, the oldest 100 period numbers are deleted in ascending period order; middle and latest records are not deleted.

## Important hosting note

GitHub is suitable for storing this source code, but GitHub Pages cannot run the Express worker or a MySQL database 24/7. For a true always-on deployment, run this Docker project on an always-on container/VPS/managed reserved service and use GitHub as the source repository. GitHub Actions is not a 24/7 server.

## Required environment

Set `DATABASE_URL` to a MySQL connection string, for example `mysql://wingo:wingo@db:3306/wingo`. `PORT` defaults to `3000`. The application has no browser-exposed API key.

## Local run

```bash
pnpm install
pnpm db:migrate
pnpm dev
```

Open `http://localhost:3000/wingo-30s` or `/`. For a production build:

```bash
pnpm install --frozen-lockfile
pnpm db:migrate
pnpm build
pnpm start
```

## Docker run

The included Dockerfile builds the app and starts the server. Build and run it with a managed MySQL database by setting `DATABASE_URL`. The server exposes `/api/health`, `/api/wingo30s/health`, and `/api/wingo30s/state`.

```bash
docker build -t wingo30s .
docker run --env DATABASE_URL='mysql://USER:PASSWORD@HOST:3306/DB' -p 3000:3000 wingo30s
```

Run the checked-in migrations once against the target database before starting the service.

## GitHub deployment

1. Create a private GitHub repository and upload the contents of this ZIP.
2. Connect the repository to your always-on container host.
3. Configure `DATABASE_URL` as a server-side secret.
4. Run `pnpm db:migrate` once during deployment.
5. Start with `pnpm start` or the Dockerfile command.
6. Configure the health check as `GET /api/health`.

Do not commit `.env`, database passwords, `node_modules`, `dist`, or GitHub tokens.

## Prediction disclaimer

The engine is a statistical ranking and diagnostics tool. Random lottery draws can be independent; expanded engines and patterns do not guarantee an outcome.
